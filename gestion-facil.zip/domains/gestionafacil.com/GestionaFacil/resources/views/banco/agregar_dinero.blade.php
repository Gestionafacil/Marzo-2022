@extends('layouts.master')
@section('title', 'Nuevo ingreso')
@section('content')
    @include('layouts.alerts')
@endsection