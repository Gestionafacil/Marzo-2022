<div class="container">
    <div class="d-flex justify-content-center row">
        <div class="col-lg-12">
            <div class="d-flex flex-column comment-section">
                <div class="bg-light p-2">
                    <div class="d-flex flex-row align-items-start">
                        <img class="rounded-circle" src="{{ asset('img/media/contact/contacto1.png') }}"
                            width="40">
                        <textarea placeholder="Escribe un comentario..."
                            class="form-control ml-1 shadow-none textarea"></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>