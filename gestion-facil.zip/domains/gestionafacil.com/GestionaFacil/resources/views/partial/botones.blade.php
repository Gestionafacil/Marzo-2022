<div class="row">
    <div class="col-lg-6 pull-left">
        <p class="text-muted text-center">Todos los campos con <span class="text-success">*</span> son de caracter
            obligatorio.</p>
    </div>
    <div class="col-lg-6 text-right">
        <button type="button" class="btn btn-outline-secondary">Cancelar</button>
        <button type="submit" name="guardarYCrearOtro" class="btn btn-outline-secondary">Guardar y crear otro</button>
        <button type="submit" name="guardarContacto"  class="btn btn-success">Crear contacto</button>
    </div>
</div>