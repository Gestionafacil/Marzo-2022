@extends('layouts.master')
@section('title', 'Nueva factura recurrente')
@section('content')
<div class="row">
    <div class="col-lg-7">
        <h3 class="text-secondary titleConfig">Nueva factura Frecuente</h3>
    </div>
</div>
<hr>
  <factura-frecuente-component></factura-frecuente-component>
@endsection