<?php

namespace GestionaFacil;

use Illuminate\Database\Eloquent\Model;

class FacturaVista extends Model
{
    protected $table = 'view_factura';
}
