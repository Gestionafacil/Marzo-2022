
<?php $__env->startSection('title', 'Pagos Recibidos'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-7">
        <h3 class="text-secondary titleConfig">Nuevo ingreso</h3>
    </div>
</div>
<hr>
<pago-recibido-component></pago-recibido-component>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>