
<?php $__env->startSection('title', 'Nueva factura'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-7">
        <h3 class="text-secondary titleConfig">Nueva factura</h3>
    </div>
</div>
<hr>

<factura-venta-component :dmetodopago="<?php echo e($metodo_Pago); ?>" 
                         :forma_pago = "<?php echo e($forma_pago); ?>" 
                         :almacen="<?php echo e($almacen); ?>" 
                         :lista_precio="<?php echo e($lista_precio); ?>" 
                         :vendedor="<?php echo e($vendedor); ?>" 
                         :contacto="<?php echo e($contacto); ?>" 
                         :plazo_pago="<?php echo e($plazo_pago); ?>" 
                         :uso="<?php echo e($uso); ?>"
                         :producto="<?php echo e($producto); ?>"
                         :impuestos="<?php echo e($impuestos); ?>"
                         >
  
</factura-venta-component>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/facturacion/factura.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>