
<?php $__env->startSection('title', 'Ajuste Inventario'); ?>
<?php $__env->startSection('content'); ?>

<!-- alerta que se muestra cuando la info sea enviada -->

<?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-lg-7">
            <h3 class="text-secondary titleConfig"><i class="fa fa-boxes"></i>Ajustes de inventario</h3>
            <p class="titleConfig text-muted">Controla las cantidades de tu inventario registrando Aumentos o Disminuciones</p>
        </div>
        <div class="col-lg-5">
            <a href="<?php echo e(route('ajusteNuevo', [])); ?>" class="btn btn-sm btn-primary float-right"><i class="fa fa-plus"></i> Nuevo ajuste de inventario</a>
        </div>
    </div>
    <hr>
    <?php echo $__env->make('inventario.partial.tabla_lista_ajuste', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>