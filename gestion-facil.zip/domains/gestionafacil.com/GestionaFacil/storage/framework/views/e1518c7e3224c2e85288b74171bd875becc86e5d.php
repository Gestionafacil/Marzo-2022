
<?php $__env->startSection('title', 'Configuración'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid">
        <img src="<?php echo e(asset('img/baseline_settings_black_24dp.png')); ?>" class="icon-header" alt="setting">
        <h3 class="text-secondary titleConfig">Configuración</h3>
        <hr>
        <div class="row card-list-config">
            <!-- Empresa -->
            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card">
                    <div class="card-header text-white text-center">
                        <h6>Empresa</h6>
                    </div>
                    <div class="card-body">
                        Configura la información de tu empresa y adapta Gestiona Facil a tu negocio.
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Empresa', [])); ?>" class="link">Empresa</a>
                        <a href="<?php echo e(route('Usuario', [])); ?>" class="link">Usuarios</a>
                        <a href="<?php echo e(route('Perfil', [])); ?>" class="link">Mi perfil</a>
                        <a href="<?php echo e(route('CentroCostos', [])); ?>" class="link">Centros de costos</a>
                    </div>
                </div>
            </div>
            <!-- \Empresa -->

            <!-- Facturación -->
            
            <!-- \Facturación -->

            <!-- Plantillas de impresión -->
            
            <!-- \Plantillas de impresión -->

            <!-- Impuestos -->
            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card">
                    <div class="card-header text-white text-center">
                        <h6>Impuestos</h6>
                    </div>
                    <div class="card-body">
                        <p>Define aquí los tipos de impuestos y retenciones que aplicas a tus facturas.</p>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Impuesto', [])); ?>" class="link">Impuestos</a>
                        <a href="#" class="link">Retenciones</a>
                        
                    </div>
                </div>
            </div>
            <!-- \Impuestos -->

            <!-- Contabilidad -->
            
            <!-- \Contabilidad -->

            <!-- Notificaciones y correos -->
            
            <!-- \Notificaciones y correos -->

            <!-- Inventario -->
            
            <!-- \Inventario -->

            <!-- Integraciones -->
            
            <!-- \Integraciones -->

            <!-- Historial -->
            
            <!-- \Historial -->

            <!-- Punto de venta (POS) -->
            
            <!-- \Punto de venta (POS) -->

            <!-- Suscripción - Planes -->
            <div class="col-lg-3 d-flex align-items-stretch">
                <div class="card">
                    <div class="card-header text-white text-center">
                        <h6>Suscripción - Planes</h6>
                    </div>
                    <div class="card-body">
                        <p>Elige el plan que quieres tener en Gestiona Facil y configura cómo quieres pagarlo.</p>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Suscripcion', [])); ?>" class="link">Suscripción</a>
                        <a href="#" class="link">Métodos de pago</a>
                    </div>
                </div>
            </div>
            <!-- \Suscripción - Planes -->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/configuracionController.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>