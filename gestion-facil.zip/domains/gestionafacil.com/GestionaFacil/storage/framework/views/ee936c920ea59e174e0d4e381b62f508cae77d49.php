<div class="row">
    <div class="col-lg-12">
        <table class="table table-hover table-sm" id="listado">
            <thead>
                <th>Nombre</th>
                <th>Identificacion</th>
                <th>Teléfono</th>
                <th>Creado</th>
                <th>Acciones</th>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/contacto/listado.js')); ?>"></script>
<?php $__env->stopSection(); ?>