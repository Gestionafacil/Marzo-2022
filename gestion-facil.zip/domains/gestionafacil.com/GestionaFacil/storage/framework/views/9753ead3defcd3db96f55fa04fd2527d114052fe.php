
<?php $__env->startSection('title', 'Almacenes'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-10">
            <h2 class="text-secondary titleConfig"> Almacenes</h2>
            <p class="titleConfig text-muted">Crea nuevos almacenes para para distribuir y gestionar tu inventario.</p>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover table-sm" id="listado">
                        <thead>
                            <th>Nombre</th>
                            <th>Dirección</th>
                            <th>Observaciones</th>
                            <th>Acciones</th>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="card">
                <div class="card-body">
                    <input type="hidden" name="id" id="id">
                    <div class="form-group">
                        <label>Nombre <span class="text-success">*</span></label>
                        <input type="text" name="nombre" id="nombre" required class="form-control form-control-sm">
                    </div>
                    <div class="form-group">
                        <label>Dirección</label>
                        <input type="text" name="direccion" id="direccion" class="form-control form-control-sm">
                    </div>
                    <div class="form-group">
                        <label>Observaciones</label>
                        <textarea cols="10" rows="3" name="observacion" id="observacion" class="form-control form-control-sm"></textarea>
                    </div>
                    <button type="reset" class="btn btn-danger" id="reset">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="guardar">Guardar</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/almacen/listado.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>