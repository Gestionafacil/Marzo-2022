<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('img/media/logos/LOGO-PNG-SOLO.png')); ?>">
    <!-- Google Font: Source Sans Pro -->
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Ionicons -->
    
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet"
        href="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/jqvmap/jqvmap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/daterangepicker/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/summernote/summernote-bs4.min.css')); ?>">
    <link href="<?php echo e(asset('preconfig-css/app.estilo.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/Dashboard.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/efecto_carga.css')); ?>">

    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/css/select2.css')); ?>">

    <!-- DataTables -->
    
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/buttons.dataTables.min.css')); ?>">

    <!-- App CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/application.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/CheckStyle.css')); ?>">
    <!-- bootstrap selector -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-chosen.css')); ?>">
</head>

<body class="hold-transition sidebar-mini">

    
    <div class="loading show" id="spinLoad" style="display: none;">
        <div class="spin"></div>
    </div>

    <?php if(current_plan()->dias_restantes <= 15): ?>
        <div id="covid-bar" class="covid-bar bg-success">
            <i class="fa fa-calendar-alt"></i>
            Te quedan <?php echo e(current_plan()->dias_restantes); ?> día(s) en la versión <?php echo e(current_plan()->nombre); ?>.
            Después podrás seleccionar el plan que desees
            <span id="buttonCovid"></span>
        </div>
    <?php endif; ?>
    <div class="wrapper">
        <!-- logo inicial  -->
        <?php if(session('logoStatus')): ?>
            <div class="preloader flex-column justify-content-center align-items-center">
                <img class="animation__shake" src="<?php echo e(asset('dist/img/logo.png')); ?>" alt="Logo" height="60"
                    width="60">
            </div>
        <?php endif; ?>
        <!--  Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                            class="fas fa-bars"></i></a></li>
                <li class="nav-item d-none d-sm-inline-block"><a href="index.php" class="nav-link"></a></li>
                <li class="nav-item d-none d-sm-inline-block"><a href="#" class="nav-link"></a></li>
            </ul>
            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <!-- Messages Dropdown Menu -->
                <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-question-circle"></i> Ayuda</a></li>
                <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-envelope"></i> Soporte</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                        <i class="far fa-bell"></i>
                        <span class="badge badge-primary">+99</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right"
                        style="left: inherit;right: 0px; overflow-y: scroll;height: 300px;">
                        <span class="dropdown-item dropdown-header text-bold">Notificaciones</span>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <a href="#" class="dropdown-item">
                            <p class="font-wight-light" style="font-size: 13px;">Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Ad, laudantium?</p>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item dropdown-footer text-primary">Mostrar todas</a>
                    </div>
                </li>
                <!-- Notifications Dropdown Menu -->
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#"><i class="far fa-user"></i></a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <span class="dropdown-item dropdown-header text-bold">Cuenta</span>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item">
                            <i class="far fa-user"></i>
                            
                            <?php echo e(current_user()->email); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item"><i class="nav-icon fas fa-tachometer-alt"></i> Consumo del
                            plan</a>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item"><i class="fas fa-cogs"></i> Configuración</a>
                        <a href="#" class="dropdown-item"><i class="fas fa-users-cog"></i> Mi perfil</a>
                        <a href="<?php echo e(route('salir', [])); ?>" id="cerraSesion" class="dropdown-item"><i
                                class="fas fa-sign-out-alt"></i> Salir</a>
                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item dropdown-footer">Gestiona facil</a>
                    </div>
                </li>
                <li class="nav-item"><a class="nav-link" data-widget="fullscreen" href="#" role="button"><i
                            class="fas fa-expand-arrows-alt"></i></a></li>
            </ul>
        </nav>
        <aside class="main-sidebar  elevation-4">
            <!-- Brand Logo -->
            <!-- Sidebar -->
            <div class="sidebar nas">
                <!-- Sidebar user panel (optional) -->
                <div class="brand-link">
                    <img src="<?php echo e(asset('dist/img/favicon-blanco.png')); ?>" alt="Logo" class="brand-image img">
                    <span class="brand-text font-weight-light"> Gestiona Facil</span>
                </div>
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <!-- Add icons to the links using the .nav-icon class with font-awesome or any other icon font library -->
                        <li class="nav-item"><a href="<?php echo e(route('Dashboard', [])); ?>" class="nav-link"><i
                                    class="nav-icon fas fa-home"></i>
                                <p>INICIO</p>
                            </a></li>
                        <li class="nav-item">
                            <a href="#" class="nav-link"><i class="nav-icon fas fa-plus-square"></i><p>INGRESOS<i class="nav-icon right fas fa-angle-left"></i></p></a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item"><a href="<?php echo e(route('facturaVenta', [])); ?>" class="nav-link"><p>Facturas de ventas</p></a></li>
                                <li class="nav-item"><a href="#" class="nav-link"><p>Facturas globales</p></a></li>
                                <li class="nav-item"><a href="<?php echo e(route('facturaFrecuente', [])); ?>" class="nav-link"><p>Facturas frecuente</p></a></li>
                                <li class="nav-item"><a href="<?php echo e(route('pagoRecibido', [])); ?>" class="nav-link"><p>Pagos recibidos</p></a></li>
                                <li class="nav-item"><a href="#" class="nav-link"><p>Notas de crédito</p></a></li>
                                <li class="nav-item"><a href="#" class="nav-link"><p>Cotizaciones</p></a></li>
                                <li class="nav-item"><a href="#" class="nav-link"><p>Remisiones</p></a></li>
                                
                            </ul> 
                        </li>
                        
                        <?php if(Auth::user()->tieneRol(['admin', 'vendedor'])): ?>
                            <li class="nav-item">
                                <a href="#" class="nav-link"><i class="nav-icon fas fa-user-friends"></i>
                                    <p>CONTACTOS<i class="nav-icon right fas fa-angle-left"></i></p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item"><a href="<?php echo e(route('ContactoTodos', [])); ?>" class="nav-link">
                                            <p>Todos</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('ContactoCliente', [])); ?>"
                                            class="nav-link">
                                            <p>Clientes</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('ContactoProveedor', [])); ?>"
                                            class="nav-link">
                                            <p>Proveedores</p>
                                        </a></li>
                                    
                                </ul>
                            </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->tieneRol('admin')): ?>
                            <li class="nav-item">
                                <a href="#" class="nav-link"><i class="nav-icon fas fa-th"></i>
                                    <p>INVENTARIO<i class="nav-icon fas fa-angle-left right"></i></p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item"><a href="<?php echo e(route('producto', [])); ?>" class="nav-link">
                                            <p>Productos de venta</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('InventarioValor', [])); ?>" class="nav-link">
                                            <p>Valor de inventario</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('ajuste', [])); ?>" class="nav-link">
                                            <p>Ajustes de inventario</p>
                                        </a></li>
                                    <li class="nav-item"><a href="#" class="nav-link">
                                            <p>Gestión de items</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('listaPrecio', [])); ?>" class="nav-link">
                                            <p>Lista de precios</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('Almacen', [])); ?>" class="nav-link">
                                            <p>Almacenes</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('Categoria', [])); ?>" class="nav-link">
                                            <p>Categorías</p>
                                        </a></li>
                                    <li class="nav-item"><a href="<?php echo e(route('Atributo', [])); ?>" class="nav-link">
                                            <p>Atributos</p>
                                        </a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item"><a href="<?php echo e(route('Banco', [])); ?>" class="nav-link"><i
                                    class="nav-icon fas fa-university"></i>
                                <p>BANCOS</p>
                            </a></li>
                        
                        
                        <?php if(Auth::user()->tieneRol('admin')): ?>
                            <li class="nav-item"><a href="<?php echo e(route('Configuracion', [])); ?>" class="nav-link"><i
                                        class="nav-icon fas fa-cogs"></i>
                                    <p>CONFIGURACIÓN</p>
                                </a></li>
                        <?php endif; ?>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>
        <div class="content-wrapper">
            <section class="content">
                <br>
                <div id="app">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </section>
        </div>
        <footer class="main-footer">
            <strong>Copyright &copy; 2021 <a href="<?php echo e(route('Dashboard', [])); ?>">Gestion Facil</a>.</strong>
            Todos los derechos reservados.
        </footer>
    </div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- ChartJS -->
    <script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>
    <!-- Sparkline -->
    <script src="<?php echo e(asset('plugins/sparklines/sparkline.js')); ?>"></script>
    <!-- JQVMap -->
    <script src="<?php echo e(asset('plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
    <!-- jQuery Knob Chart -->
    <script src="<?php echo e(asset('plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
    <!-- daterangepicker -->
    <script src="<?php echo e(asset('plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>">
    </script>
    <!-- Summernote -->
    <script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo e(asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
    <!-- AdminLTE for demo purposes -->

    <!-- DataTables -->
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chosen.jquery.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2@10.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/application.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
