
<?php $__env->startSection('title', 'Facturas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-7">
            <h3 class="text-secondary titleConfig"><i class="fa fa-shield-alt"></i>Facturas y tickets</h3>
        </div>
        <div class="col-lg-5">
            <a href="<?php echo e(route('nuevaFacturaVenta', [])); ?>" class="btn btn-sm btn-primary float-right"><i class="fa fa-plus"></i>
                Nueva factura de venta</a>
        </div>
    </div>
    <hr>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="">
                <table class="table table-hover table-sm" id="listado">
                    <thead>
                        <th>Folio</th>
                        <th>Cliente</th>
                        <th>Creacion</th>
                        <th>Vencimiento</th>
                        <th>Total</th>
                        <th>Cobrado</th>
                        <th>Por cobrar</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/facturaVenta/listado.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>