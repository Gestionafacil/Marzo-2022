
<?php $__env->startSection('title', 'Proveedores'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-7">
            <h3 class="text-secondary titleConfig"><i class="fa fa-users"></i>Proveedores</h3>
            <p class="titleConfig text-muted">Crea los contactos que asociarás en tus documentos y transacciones de egresos.</p>
        </div>
        <div class="col-lg-5">
            <button class="btn btn-sm btn-outline-secondary"><i class="fa fa-upload"></i> Importar desde Excel</button>
            <button class="btn btn-sm btn-outline-secondary"><i class="fa fa-download"></i> Exportar</button>
            <a href="<?php echo e(route('ContactoNuevo', [])); ?>?type=Proveedor" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Nuevo proveedor</a>
        </div>
    </div>
    <hr>
    <?php echo $__env->make('contacto.partial.tabla_listado_contacto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>