
<?php $__env->startSection('title', 'Editar . . .'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-7">
            <h3 class="text-secondary titleConfig"><i class="fa fa-boxes"></i>Editar producto</h3>
            <p class="titleConfig text-muted">Edita tus productos inventariables y/o servicios que ofreces
                para registrar en tus ventas.</p>
        </div>
    </div>
    <hr>
    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('inventario.partial.formulario_producto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/inventario/producto/formulario.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app/inventario/producto/editar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>