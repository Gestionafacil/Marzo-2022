
<?php $__env->startSection('title', 'Atributos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-10">
            <h2 class="text-secondary titleConfig"> Atributos</h2>
            <p class="titleConfig text-muted">Agrega información adicional y personaliza las características de tus productos de venta.</p>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('AtributoVariante', [])); ?>" class="h6 text-center text-white">Variantes</a>
                </div>
                <div class="card-body">
                    <p>Configura atributos variables que definen las características de tus productos, como color y talla.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('AtributoCampo', [])); ?>" class="h6 text-center text-white">Campos adicionales</a>
                </div>
                <div class="card-body">
                    <p>Crea campos adicionales para agregar información extra en tus items, como el código de barras.</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>