
<?php $__env->startSection('title', 'Categorías'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-10">
            <h2 class="text-secondary titleConfig"> Categorías</h2>
            <p class="titleConfig text-muted">Utiliza las categorías para clasificar tus productos.</p>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover table-sm" id="listado">
                        <thead>
                            <th>Nombre</th>
                            <th>Descripcion</th>
                            <th>Acciones</th>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                    <span class="h6 text-white font-weight-light">Nueva Categoría</span>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Nombre <span class="text-success">*</span></label>
                        <input type="hidden" name="id" id="id">
                        <input type="text" name="nombre" id="nombre" required class="form-control form-control-sm">
                    </div>
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea cols="10" rows="3" name="descripcion" id="descripcion" class="form-control form-control-sm"></textarea>
                    </div>
                    <button type="button" class="btn btn-danger" id="reset">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="guardar">Guardar</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/categoria/listado.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>