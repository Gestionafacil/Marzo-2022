
<?php $__env->startSection('title', 'Contacto Todos'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-7">
            <h3 class="text-secondary titleConfig"><i class="fa fa-users"></i>Contactos</h3>
            <p class="titleConfig text-muted">Crea tus clientes, proveedores y demás contactos para asociarlos en tus documentos.</p>
        </div>
        <div class="col-lg-5">
            <button class="btn btn-sm btn-outline-secondary"><i class="fa fa-upload"></i> Importar desde Excel</button>
            <button class="btn btn-sm btn-outline-secondary"><i class="fa fa-download"></i> Exportar</button>
            <a href="<?php echo e(route('ContactoNuevo', [])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Nuevo contacto</a>
        </div>
    </div>
    <hr>
    <?php echo $__env->make('contacto.partial.tabla_listado_contacto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>